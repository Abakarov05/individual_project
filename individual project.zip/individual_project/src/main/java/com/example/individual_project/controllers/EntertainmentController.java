package com.example.individual_project.controllers;

import com.example.individual_project.models.*;
import com.example.individual_project.repositories.CountryRepository;
import com.example.individual_project.repositories.EntertainmentRepository;
import com.example.individual_project.repositories.StatusRepository;
import com.example.individual_project.repositories.TypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class EntertainmentController {

  private final EntertainmentRepository entertainmentRepository;
  private final TypeRepository typeRepository;
  private final CountryRepository countryRepository;
  private final StatusRepository statusRepository;

  @Autowired
  public EntertainmentController(EntertainmentRepository entertainmentRepository, TypeRepository typeRepository, CountryRepository countryRepository, StatusRepository statusRepository) {
    this.entertainmentRepository = entertainmentRepository;
    this.typeRepository = typeRepository;
    this.countryRepository = countryRepository;
    this.statusRepository = statusRepository;
  }

  @GetMapping("/entertainment")
  public String entertainmentMain(Model model) {
    Iterable<Entertainment> entertainments = entertainmentRepository.findAll();
    model.addAttribute("entertainment", entertainments);
    return "/view/entertainment";
  }

  @GetMapping("/entertainment/add")
  public String entertainmentAdd(Entertainment entertainment, Model model) {


    Iterable<Type> type = typeRepository.findAll();
    model.addAttribute("type", type);
    Iterable<Country> country = countryRepository.findAll();
    model.addAttribute("country", country);
    Iterable<Status> status = statusRepository.findAll();
    model.addAttribute("status", status);
    return "/add/entertainment";
  }

  @PostMapping("/entertainment/add")
  public String entertainmentCountryAdd(@Valid Entertainment entertainment,
                                        BindingResult bindingResult,
                                        @RequestParam String title,
                                        @RequestParam String content,
                                        @RequestParam String episodes,
                                        @RequestParam String chapters,
                                        @RequestParam String typeName,
                                        @RequestParam String name,
                                        @RequestParam String statusName, Model model) {
    if (bindingResult.hasErrors()) {
      Iterable<Type> type = typeRepository.findAll();
      model.addAttribute("type", type);
      Iterable<Country> country = countryRepository.findAll();
      model.addAttribute("country", country);
      Iterable<Status> status = statusRepository.findAll();
      model.addAttribute("status", status);
      return "/add/entertainment";
    }

    List<Entertainment> res = entertainmentRepository.findByTitle(title);
    Type type = typeRepository.findTypeByTypeName(typeName);
    Country country = countryRepository.findCountryByName(name);
    Status status = statusRepository.findStatusByStatusName(statusName);

    if (res.size() > 0) {
      ObjectError error = new ObjectError("title", "Field is taken");
      ObjectError errorContent = new ObjectError("content", "Field is taken");
      ObjectError errorEpisodes = new ObjectError("episodes", "Field is taken");
      ObjectError errorChapters = new ObjectError("chapters", "Field is taken");
      bindingResult.addError(error);
      bindingResult.addError(errorContent);
      bindingResult.addError(errorEpisodes);
      bindingResult.addError(errorChapters);
      return "/add/entertainment";
    } else {
      Entertainment entertainment1 = new Entertainment(title, content, episodes, chapters, type, country, status);
      entertainmentRepository.save(entertainment1);
      return "redirect:/entertainment";
    }
  }

  @GetMapping("/entertainment/search")
  public String entertainmentSearch(Model model) {
    return "/search/entertainment";
  }

  @PostMapping("/entertainment/search/result")
  public String entertainmentSearchResult(@RequestParam String title, Model model) {
    List<Entertainment> result = entertainmentRepository.findByTitle(title);
    model.addAttribute("result", result);

    List<Entertainment> searchResult = entertainmentRepository.findByTitleContaining(title);
    model.addAttribute("searchResult", searchResult);
    return "/search/entertainment";
  }

  @GetMapping("/entertainment/{id}")
  public String entertainmentDetails(@PathVariable(value = "id") long id, Model model) {
    Optional<Entertainment> entertainment = entertainmentRepository.findById(id);
    ArrayList<Entertainment> res = new ArrayList<>();
    entertainment.ifPresent(res::add);
    model.addAttribute("entertainment", res);
    return "/details/entertainment";
  }

  @GetMapping("/entertainment/{id}/delete")
  public String entertainmentDelete(@PathVariable(value = "id") long id, Model model) {
    Entertainment entertainment = entertainmentRepository.findById(id).orElseThrow();
    entertainmentRepository.delete(entertainment);
    return "redirect:/entertainment";
  }

  @GetMapping("/entertainment/{id}/edit")
  public String entertainmentEdit(@PathVariable(value = "id") long id, Entertainment entertainment, Model model) {
    if (!entertainmentRepository.existsById(id)) {
      return "redirect:/entertainment";
    }
    Optional<Entertainment> entertainment1 = entertainmentRepository.findById(id);
    ArrayList<Entertainment> res = new ArrayList<>();
    entertainment1.ifPresent(res::add);
    model.addAttribute("entertainmentEdit", res);
    Iterable<Type> typeselect = typeRepository.findAll();
    model.addAttribute("typeselect", typeselect);
    Iterable<Country> countryselect = countryRepository.findAll();
    model.addAttribute("countryselect", countryselect);
    Iterable<Status> statusselect = statusRepository.findAll();
    model.addAttribute("statusselect", statusselect);
    return "/edit/entertainment";
  }

  @PostMapping("/entertainment/{id}/edit")
  public String cinemaEntertainmentEdit(@Valid Entertainment entertainment,
                                        BindingResult bindingResult,
                                        @PathVariable(value = "id") long id,
                                        @RequestParam String title,
                                        @RequestParam Long type,
                                        @RequestParam Long country,
                                        @RequestParam Long status,
                                        Model model) {

    if (bindingResult.hasErrors()) {
      Optional<Entertainment> entertainment1 = entertainmentRepository.findById(id);
      ArrayList<Entertainment> res = new ArrayList<>();
      entertainment1.ifPresent(res::add);
      model.addAttribute("entertainmentEdit", res);
      Iterable<Type> typeselect = typeRepository.findAll();
      model.addAttribute("typeselect", typeselect);
      Iterable<Country> countryselect = countryRepository.findAll();
      model.addAttribute("countryselect", countryselect);
      Iterable<Status> statusselect = statusRepository.findAll();
      model.addAttribute("statusselect", statusselect);
      return "/edit/entertainment";
    }
      Type type_object = typeRepository.findById(type).orElseThrow();
      Country country_object = countryRepository.findById(country).orElseThrow();
      Status status_object = statusRepository.findById(status).orElseThrow();

      entertainment.setType(type_object);
      entertainment.setCountry(country_object);
      entertainment.setStatus(status_object);

      entertainmentRepository.save(entertainment);
      return "redirect:/entertainment";
    }
  }

//  @PostMapping("/country/{id}/edit")
//  public String cinemaCountryEdit(@Valid Country country,
//                                  BindingResult bindingResult,
//                                  @PathVariable(value = "id") long id,
//                                  @RequestParam String name,
//                                  Model model) {
//    List<Country> res = countryRepository.findByName(name);
//
//    if (bindingResult.hasErrors()) {
//      res = new ArrayList<>();
//      res.add(country);
//      model.addAttribute("countryEdit", res);
//      return "/edit/country";
//    }
//
//    if (res.size() > 0) {
//      ObjectError errorTitle = new ObjectError("name", "Name is taken");
//      bindingResult.addError(errorTitle);
//      res = new ArrayList<>();
//      res.add(country);
//      model.addAttribute("countryEdit", res);
//      return "/edit/country";
//    } else {
//      countryRepository.save(country);
//      return "redirect:/country";
//    }
//  }

