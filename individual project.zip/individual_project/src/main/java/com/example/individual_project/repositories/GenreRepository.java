package com.example.individual_project.repositories;

import com.example.individual_project.models.Author;
import com.example.individual_project.models.Genre;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface GenreRepository extends CrudRepository<Genre, Long> {
  List<Genre> findByName(String name);
  List<Genre> findByNameContaining(String name);
  Genre findGenreByName(String name);
}
