package com.example.individual_project.repositories;

import com.example.individual_project.models.Status;
import com.example.individual_project.models.Type;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface TypeRepository extends CrudRepository<Type, Long> {
  List<Type> findByTypeName(String typeName);
  List<Type> findByTypeNameContaining(String typeName);
  Type findTypeByTypeName(String typeName);
}
