package com.example.individual_project.models;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import java.util.List;

@Entity
public class Genre {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @NotEmpty(message = "The field can't be empty")
  private String name;
  @ManyToMany
  @JoinTable(name = "genre_entertainment", joinColumns = @JoinColumn(name = "genre_id"), inverseJoinColumns = @JoinColumn(name = "entertainment_id"))
  private List<Entertainment> entertainments;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getGenreName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<Entertainment> getEntertainments() {
    return entertainments;
  }

  public void setEntertainments(List<Entertainment> entertainments) {
    this.entertainments = entertainments;
  }

  public Genre(String name, List<Entertainment> entertainments) {
    this.name = name;
    this.entertainments = entertainments;
  }

  public Genre(){}
}
