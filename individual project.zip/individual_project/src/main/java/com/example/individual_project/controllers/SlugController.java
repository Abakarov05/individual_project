package com.example.individual_project.controllers;

import com.example.individual_project.models.Slug;
import com.example.individual_project.repositories.SlugRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class SlugController {

  private final SlugRepository slugRepository;

  @Autowired
  public SlugController(SlugRepository slugRepository) {
    this.slugRepository = slugRepository;
  }

  @GetMapping("/slug")
  public String slugMain(Model model) {
    Iterable<Slug> slug = slugRepository.findAll();
    model.addAttribute("slug", slug);
    return "/view/slug";
  }

  @GetMapping("/slug/add")
  public String slugAdd(Slug slug) {
    return "/add/slug";
  }

  @PostMapping("/slug/add")
  public String cinemaSlugAdd(@Valid Slug slug,
                               BindingResult bindingResult,
                               @RequestParam String age) {
    if (bindingResult.hasErrors()) {
      return "/add/slug";
    }

    List<Slug> res = slugRepository.findByAge(age);

    if (res.size() > 0) {
      ObjectError error = new ObjectError("age", "Field is taken");
      bindingResult.addError(error);
      return "/add/slug";
    } else {
      slugRepository.save(slug);
      return "redirect:/slug";
    }
  }

  @GetMapping("/slug/search")
  public String slugSearch(Model model) {
    return "/search/slug";
  }

  @PostMapping("/slug/search/result")
  public String slugSearchResult(@RequestParam String age, Model model) {
    List<Slug> result = slugRepository.findByAge(age);
    model.addAttribute("result", result);

    List<Slug> searchResult = slugRepository.findByAgeContaining(age);
    model.addAttribute("searchResult", searchResult);
    return "/search/slug";
  }

  @GetMapping("/slug/{id}/delete")
  public String slugDelete(@PathVariable(value = "id") long id, Model model) {
    Slug slug = slugRepository.findById(id).orElseThrow();
    slugRepository.delete(slug);
    return "redirect:/slug";
  }

  @GetMapping("/slug/{id}/edit")
  public String slugEdit(@PathVariable(value = "id") long id, Slug slug, Model model) {
    if (!slugRepository.existsById(id)) {
      return "redirect:/slug";
    }
    Optional<Slug> slug1 = slugRepository.findById(id);
    ArrayList<Slug> res = new ArrayList<>();
    slug1.ifPresent(res::add);
    model.addAttribute("slugEdit", res);
    return "/edit/slug";
  }

  @PostMapping("/slug/{id}/edit")
  public String cinemaSlugEdit(@Valid Slug slug,
                                  BindingResult bindingResult,
                                  @PathVariable(value = "id") long id,
                                  @RequestParam String age,
                                  Model model) {
    List<Slug> res = slugRepository.findByAge(age);

    if (bindingResult.hasErrors()) {
      res = new ArrayList<>();
      res.add(slug);
      model.addAttribute("slugEdit", res);
      return "/edit/slug";
    }

    if (res.size() > 0) {
      ObjectError errorSlug = new ObjectError("Age", "Age is taken");;
      bindingResult.addError(errorSlug);
      res = new ArrayList<>();
      res.add(slug);
      model.addAttribute("slugEdit", res);
      return "/edit/slug";
    } else {
      slugRepository.save(slug);
      return "redirect:/slug";
    }
  }
}
