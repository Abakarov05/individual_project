package com.example.individual_project.controllers;

import com.example.individual_project.models.Country;
import com.example.individual_project.models.Slug;
import com.example.individual_project.repositories.CountryRepository;
import com.example.individual_project.repositories.SlugRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class CountryController {

  private final CountryRepository countryRepository;
  private final SlugRepository slugRepository;

  @Autowired
  public CountryController(CountryRepository countryRepository, SlugRepository slugRepository) {
    this.countryRepository = countryRepository;
    this.slugRepository = slugRepository;
  }

  @GetMapping("/country")
  public String countryMain(Model model) {
    Iterable<Country> country = countryRepository.findAll();
    model.addAttribute("country", country);
    return "/view/country";
  }

  @GetMapping("/country/add")
  public String countryAdd(Country country, Model model) {
    Iterable<Slug> slug = slugRepository.findAll();
    model.addAttribute("slug", slug);
    return "/add/country";
  }

  @PostMapping("/country/add")
  public String cinemaCountryAdd(@Valid Country country,
                               BindingResult bindingResult,
                               @RequestParam String name,
                               @RequestParam String age) {
    if (bindingResult.hasErrors()) {
      return "/add/country";
    }

    List<Country> res = countryRepository.findByName(name);
    Slug slug = slugRepository.findSlugByAge(age);

    if (res.size() > 0) {
      ObjectError error = new ObjectError("name", "Field is taken");
      bindingResult.addError(error);
      return "/add/country";
    } else {
      Country country1 = new Country(name, slug);
      countryRepository.save(country1);
      return "redirect:/country";
    }
  }

  @GetMapping("/country/search")
  public String countrySearch(Model model) {
    return "/search/country";
  }

  @PostMapping("/country/search/result")
  public String countrySearchResult(@RequestParam String name, Model model) {
    List<Country> result = countryRepository.findByName(name);
    model.addAttribute("result", result);

    List<Country> searchResult = countryRepository.findByNameContaining(name);
    model.addAttribute("searchResult", searchResult);
    return "/search/country";
  }

  @GetMapping("/country/{id}/delete")
  public String countryDelete(@PathVariable(value = "id") long id, Model model) {
    Country country = countryRepository.findById(id).orElseThrow();
    countryRepository.delete(country);
    return "redirect:/country";
  }

  @GetMapping("/country/{id}/edit")
  public String countryEdit(@PathVariable(value = "id") long id, Country Country, Model model) {
    if (!countryRepository.existsById(id)) {
      return "redirect:/country";
    }
    Optional<Country> country = countryRepository.findById(id);
    ArrayList<Country> res = new ArrayList<>();
    country.ifPresent(res::add);
    model.addAttribute("countryEdit", res);
    Iterable<Slug> slug = slugRepository.findAll();
    model.addAttribute("slug", slug);
    return "/edit/country";
  }

  @PostMapping("/country/{id}/edit")
  public String cinemaCountryEdit(@Valid Country country,
                                  BindingResult bindingResult,
                                  @PathVariable(value = "id") long id,
                                  @RequestParam String name,
                                  Model model) {
    List<Country> res = countryRepository.findByName(name);

    if (bindingResult.hasErrors()) {
      res = new ArrayList<>();
      res.add(country);
      model.addAttribute("countryEdit", res);
      return "/edit/country";
    }

    if (res.size() > 0) {
      ObjectError errorTitle = new ObjectError("name", "Name is taken");
      bindingResult.addError(errorTitle);
      res = new ArrayList<>();
      res.add(country);
      model.addAttribute("countryEdit", res);
      return "/edit/country";
    } else {
      countryRepository.save(country);
      return "redirect:/country";
    }
  }
}
