package com.example.individual_project.models;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import java.util.Collection;

@Entity
public class Slug {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @NotEmpty(message = "The field can't be empty")
  private String age;
  @OneToMany(mappedBy = "slug", fetch = FetchType.LAZY)
  private Collection<Country> countries;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getAge() {
    return age;
  }

  public void setAge(String age) {
    this.age = age;
  }

  public Collection<Country> getCountries() {
    return countries;
  }

  public void setCountries(Collection<Country> countries) {
    this.countries = countries;
  }

  public Slug(String age, Collection<Country> countries) {
    this.age = age;
    this.countries = countries;
  }

  public Slug(){}
}
