package com.example.individual_project.repositories;

import com.example.individual_project.models.Author;
import com.example.individual_project.models.Slug;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface SlugRepository extends CrudRepository<Slug, Long> {
  List<Slug> findByAge(String age);
  List<Slug> findByAgeContaining(String age);
  Slug findSlugByAge(String age);
}
