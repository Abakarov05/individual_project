package com.example.individual_project.controllers;

import com.example.individual_project.models.Author;
import com.example.individual_project.models.Entertainment;
import com.example.individual_project.models.Genre;
import com.example.individual_project.repositories.EntertainmentRepository;
import com.example.individual_project.repositories.GenreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class EntertainmentAndGenreController {

  private final EntertainmentRepository entertainmentRepository;
  private final GenreRepository genreRepository;

  @Autowired
  public EntertainmentAndGenreController(EntertainmentRepository entertainmentRepository, GenreRepository genreRepository) {
    this.entertainmentRepository = entertainmentRepository;
    this.genreRepository = genreRepository;
  }

  @GetMapping("/entertainment_and_genre")
  public String entertainmentAndGenreMain(Model model) {
    Iterable<Entertainment> entertainments = entertainmentRepository.findAll();
    model.addAttribute("entertainments", entertainments);
    Iterable<Genre> genres = genreRepository.findAll();
    model.addAttribute("genres", genres);
    return "/add/entertainmentAndGenre";
  }

  @PostMapping("/person1")
  public String entertainmentAndGenreAdd(@RequestParam String entertainment, @RequestParam String genre, Model model) {
    Entertainment entertainment1 = entertainmentRepository.findEntertainmentByTitle(entertainment);
    Genre genre1 = genreRepository.findGenreByName(genre);
    var entertainments = genre1.getEntertainments();
    entertainments.add(entertainment1);
    genre1.setEntertainments(entertainments);
    entertainmentRepository.save(entertainment1);
    return "/add/entertainmentAndGenre";
  }
}
