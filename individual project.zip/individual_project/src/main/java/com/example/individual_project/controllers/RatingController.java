package com.example.individual_project.controllers;

import com.example.individual_project.models.Country;
import com.example.individual_project.models.Entertainment;
import com.example.individual_project.models.Rating;
import com.example.individual_project.models.Slug;
import com.example.individual_project.repositories.EntertainmentRepository;
import com.example.individual_project.repositories.RatingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class RatingController {

  private final RatingRepository ratingRepository;
  private final EntertainmentRepository entertainmentRepository;

  @Autowired
  public RatingController(RatingRepository ratingRepository, EntertainmentRepository entertainmentRepository) {
    this.ratingRepository = ratingRepository;
    this.entertainmentRepository = entertainmentRepository;
  }

  @GetMapping("/rating")
  public String ratingMain(Model model) {
    Iterable<Rating> ratings = ratingRepository.findAll();
    model.addAttribute("rating", ratings);
    return "/view/rating";
  }

  @GetMapping("/rating/add")
  public String ratingAdd(Rating rating, Model model) {
    Iterable<Entertainment> entertainments = entertainmentRepository.findAll();
    model.addAttribute("entertainment", entertainments);
    return "/add/rating";
  }

  @PostMapping("/rating/add")
  public String cinemaRatingAdd(@Valid Rating rating,
                                 BindingResult bindingResult,
                                 @RequestParam String name,
                                 @RequestParam String entertainment) {
    if (bindingResult.hasErrors()) {
      return "/add/rating";
    }

    List<Rating> res = ratingRepository.findByName(name);
    Entertainment entertainment1 = entertainmentRepository.findEntertainmentByTitle(entertainment);

    if (res.size() > 0) {
      ObjectError error = new ObjectError("name", "Field is taken");
      bindingResult.addError(error);
      return "/add/rating";
    } else {
      Rating rating1 = new Rating(name, entertainment1);
      ratingRepository.save(rating1);
      return "redirect:/rating";
    }
  }

  @GetMapping("/rating/search")
  public String ratingSearch(Model model) {
    return "/search/rating";
  }

  @PostMapping("/rating/search/result")
  public String ratingSearchResult(@RequestParam String name, Model model) {
    List<Rating> result = ratingRepository.findByName(name);
    model.addAttribute("result", result);

    List<Rating> searchResult = ratingRepository.findByNameContaining(name);
    model.addAttribute("searchResult", searchResult);
    return "/search/rating";
  }

  @GetMapping("/rating/{id}/delete")
  public String ratingDelete(@PathVariable(value = "id") long id, Model model) {
    Rating rating = ratingRepository.findById(id).orElseThrow();
    ratingRepository.delete(rating);
    return "redirect:/rating";
  }

  @GetMapping("/rating/{id}/edit")
  public String ratingEdit(@PathVariable(value = "id") long id, Rating rating, Model model) {
    if (!ratingRepository.existsById(id)) {
      return "redirect:/rating";
    }
    Optional<Rating> rating1 = ratingRepository.findById(id);
    ArrayList<Rating> res = new ArrayList<>();
    rating1.ifPresent(res::add);
    model.addAttribute("ratingEdit", res);
    Iterable<Entertainment> entertainments = entertainmentRepository.findAll();
    model.addAttribute("entertainment", entertainments);
    return "/edit/rating";
  }

  @PostMapping("/rating/{id}/edit")
  public String cinemaRatingEdit(@Valid Rating rating,
                                  BindingResult bindingResult,
                                  @PathVariable(value = "id") long id,
                                  @RequestParam String name,
                                  Model model) {
    List<Rating> res = ratingRepository.findByName(name);

    if (bindingResult.hasErrors()) {
      res = new ArrayList<>();
      res.add(rating);
      model.addAttribute("ratingEdit", res);
      return "/edit/rating";
    }

    if (res.size() > 0) {
      ObjectError errorTitle = new ObjectError("name", "Name is taken");
      bindingResult.addError(errorTitle);
      res = new ArrayList<>();
      res.add(rating);
      model.addAttribute("ratingEdit", res);
      return "/edit/rating";
    } else {
      ratingRepository.save(rating);
      return "redirect:/rating";
    }
  }
}
