package com.example.individual_project.models;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import java.util.Collection;

@Entity
public class Type {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @NotEmpty(message = "The field can't be empty")
  private String typeName;
  @OneToMany(mappedBy = "type", fetch = FetchType.LAZY)
  private Collection<Entertainment> entertainments;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getTypeName() {
    return typeName;
  }

  public void setTypeName(String typeName) {
    this.typeName = typeName;
  }

  public Collection<Entertainment> getEntertainments() {
    return entertainments;
  }

  public void setEntertainments(Collection<Entertainment> entertainments) {
    this.entertainments = entertainments;
  }

  public Type(String typeName, Collection<Entertainment> entertainments) {
    this.typeName = typeName;
    this.entertainments = entertainments;
  }

  public Type(){}
}
