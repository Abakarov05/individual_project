package com.example.individual_project.controllers;

import com.example.individual_project.models.Slug;
import com.example.individual_project.models.Status;
import com.example.individual_project.repositories.StatusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class StatusController {
  private final StatusRepository statusRepository;

  @Autowired
  public StatusController(StatusRepository statusRepository) {
    this.statusRepository = statusRepository;
  }

  @GetMapping("/status")
  public String statusMain(Model model) {
    Iterable<Status> status = statusRepository.findAll();
    model.addAttribute("status", status);
    return "/view/status";
  }

  @GetMapping("/status/add")
  public String statusAdd(Status status) {
    return "/add/status";
  }

  @PostMapping("/status/add")
  public String cinemaStatusAdd(@Valid Status status,
                                BindingResult bindingResult,
                                @RequestParam String statusName) {
    if (bindingResult.hasErrors()) {
      return "/add/status";
    }

    List<Status> res = statusRepository.findByStatusName(statusName);

    if (res.size() > 0) {
      ObjectError error = new ObjectError("statusName", "Field is taken");
      bindingResult.addError(error);
      return "/add/status";
    } else {
      statusRepository.save(status);
      return "redirect:/status";
    }
  }

  @GetMapping("/status/search")
  public String statusSearch(Model model) {
    return "/search/status";
  }

  @PostMapping("/status/search/result")
  public String statusSearchResult(@RequestParam String statusName, Model model) {
    List<Status> result = statusRepository.findByStatusName(statusName);
    model.addAttribute("result", result);

    List<Status> searchResult = statusRepository.findByStatusNameContaining(statusName);
    model.addAttribute("searchResult", searchResult);
    return "/search/status";
  }

  @GetMapping("/status/{id}/delete")
  public String statusDelete(@PathVariable(value = "id") long id, Model model) {
    Status status = statusRepository.findById(id).orElseThrow();
    statusRepository.delete(status);
    return "redirect:/status";
  }

  @GetMapping("/status/{id}/edit")
  public String statusEdit(@PathVariable(value = "id") long id, Status status, Model model) {
    if (!statusRepository.existsById(id)) {
      return "redirect:/status";
    }
    Optional<Status> status1 = statusRepository.findById(id);
    ArrayList<Status> res = new ArrayList<>();
    status1.ifPresent(res::add);
    model.addAttribute("statusEdit", res);
    return "/edit/status";
  }

  @PostMapping("/status/{id}/edit")
  public String cinemaStatusEdit(@Valid Status status,
                                 BindingResult bindingResult,
                                 @PathVariable(value = "id") long id,
                                 @RequestParam String statusName,
                                 Model model) {
    List<Status> res = statusRepository.findByStatusName(statusName);

    if (bindingResult.hasErrors()) {
      res = new ArrayList<>();
      res.add(status);
      model.addAttribute("statusEdit", res);
      return "/edit/status";
    }

    if (res.size() > 0) {
      ObjectError errorSlug = new ObjectError("statusName", "Status name is taken");
      ;
      bindingResult.addError(errorSlug);
      res = new ArrayList<>();
      res.add(status);
      model.addAttribute("statusEdit", res);
      return "/edit/status";
    } else {
      statusRepository.save(status);
      return "redirect:/status";
    }
  }
}
