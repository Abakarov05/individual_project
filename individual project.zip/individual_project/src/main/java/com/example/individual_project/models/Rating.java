package com.example.individual_project.models;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "rating")
public class Rating {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @NotEmpty(message = "The field can't be empty")
  private String name;
  @ManyToOne(optional = true, cascade = CascadeType.DETACH)
  private Entertainment entertainment;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Entertainment getEntertainment() {
    return entertainment;
  }

  public void setEntertainments(Entertainment entertainment) {
    this.entertainment = entertainment;
  }

  public Rating(String name, Entertainment entertainment) {
    this.name = name;
    this.entertainment = entertainment;
  }

  public Rating() {
  }
}
