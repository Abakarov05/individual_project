package com.example.individual_project.controllers;

import com.example.individual_project.models.Genre;
import com.example.individual_project.repositories.GenreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class GenreController {
  private final GenreRepository genreRepository;

  @Autowired
  public GenreController(GenreRepository genreRepository) {
    this.genreRepository = genreRepository;
  }

  @GetMapping("/genre")
  public String genreMain(Model model) {
    Iterable<Genre> genre = genreRepository.findAll();
    model.addAttribute("genre", genre);
    return "/view/genre";
  }

  @GetMapping("/genre/add")
  public String genreAdd(Genre genre) {
    return "/add/genre";
  }

  @PostMapping("/genre/add")
  public String cinemaGenreAdd(@Valid Genre genre,
                               BindingResult bindingResult,
                               @RequestParam String name) {
    if (bindingResult.hasErrors()) {
      return "/add/genre";
    }

    List<Genre> res = genreRepository.findByName(name);

    if (res.size() > 0) {
      ObjectError error = new ObjectError("name", "Field is taken");
      bindingResult.addError(error);
      return "/add/genre";
    } else {
      genreRepository.save(genre);
      return "redirect:/genre";
    }
  }

  @GetMapping("/genre/search")
  public String genreSearch(Model model) {
    return "/search/genre";
  }

  @PostMapping("/genre/search/result")
  public String genreSearchResult(@RequestParam String name, Model model) {
    List<Genre> result = genreRepository.findByName(name);
    model.addAttribute("result", result);

    List<Genre> searchResult = genreRepository.findByNameContaining(name);
    model.addAttribute("searchResult", searchResult);
    return "/search/genre";
  }

  @GetMapping("/genre/{id}/delete")
  public String genreDelete(@PathVariable(value = "id") long id, Model model) {
    Genre genre = genreRepository.findById(id).orElseThrow();
    genreRepository.delete(genre);
    return "redirect:/genre";
  }

  @GetMapping("/genre/{id}/edit")
  public String genreEdit(@PathVariable(value = "id") long id, Genre genre, Model model) {
    if (!genreRepository.existsById(id)) {
      return "redirect:/genre";
    }
    Optional<Genre> genre1 = genreRepository.findById(id);
    ArrayList<Genre> res = new ArrayList<>();
    genre1.ifPresent(res::add);
    model.addAttribute("genreEdit", res);
    return "/edit/genre";
  }

  @PostMapping("/genre/{id}/edit")
  public String cinemaGenreEdit(@Valid Genre genre,
                                  BindingResult bindingResult,
                                  @PathVariable(value = "id") long id,
                                  @RequestParam String name,
                                  Model model) {
    List<Genre> res = genreRepository.findByName(name);

    if (bindingResult.hasErrors()) {
      res = new ArrayList<>();
      res.add(genre);
      model.addAttribute("genreEdit", res);
      return "/edit/genre";
    }

    if (res.size() > 0) {
      ObjectError errorTitle = new ObjectError("name", "Name is taken");
      bindingResult.addError(errorTitle);
      res = new ArrayList<>();
      res.add(genre);
      model.addAttribute("genreEdit", res);
      return "/edit/genre";
    } else {
      genreRepository.save(genre);
      return "redirect:/genre";
    }
  }
}
