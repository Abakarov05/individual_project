package com.example.individual_project.controllers;

import com.example.individual_project.models.Slug;
import com.example.individual_project.models.Status;
import com.example.individual_project.models.Type;
import com.example.individual_project.repositories.TypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class TypeController {

  private final TypeRepository typeRepository;

  @Autowired
  public TypeController(TypeRepository typeRepository) {
    this.typeRepository = typeRepository;
  }

  @GetMapping("/type")
  public String typeMain(Model model) {
    Iterable<Type> type = typeRepository.findAll();
    model.addAttribute("type", type);
    return "/view/type";
  }

  @GetMapping("/type/add")
  public String typeAdd(Type type) {
    return "/add/type";
  }

  @PostMapping("/type/add")
  public String cinemaTypeAdd(@Valid Type type,
                                BindingResult bindingResult,
                                @RequestParam String typeName) {
    if (bindingResult.hasErrors()) {
      return "/add/type";
    }

    List<Type> res = typeRepository.findByTypeName(typeName);

    if (res.size() > 0) {
      ObjectError error = new ObjectError("typeName", "Field is taken");
      bindingResult.addError(error);
      return "/add/type";
    } else {
      typeRepository.save(type);
      return "redirect:/type";
    }
  }

  @GetMapping("/type/search")
  public String typeSearch(Model model) {
    return "/search/type";
  }

  @PostMapping("/type/search/result")
  public String typeSearchResult(@RequestParam String typeName, Model model) {
    List<Type> result = typeRepository.findByTypeName(typeName);
    model.addAttribute("result", result);

    List<Type> searchResult = typeRepository.findByTypeNameContaining(typeName);
    model.addAttribute("searchResult", searchResult);
    return "/search/type";
  }

  @GetMapping("/type/{id}/delete")
  public String typeDelete(@PathVariable(value = "id") long id, Model model) {
    Type type = typeRepository.findById(id).orElseThrow();
    typeRepository.delete(type);
    return "redirect:/type";
  }

  @GetMapping("/type/{id}/edit")
  public String typeEdit(@PathVariable(value = "id") long id, Type type, Model model) {
    if (!typeRepository.existsById(id)) {
      return "redirect:/type";
    }
    Optional<Type> type1 = typeRepository.findById(id);
    ArrayList<Type> res = new ArrayList<>();
    type1.ifPresent(res::add);
    model.addAttribute("typeEdit", res);
    return "/edit/type";
  }

  @PostMapping("/type/{id}/edit")
  public String cinemaTypeEdit(@Valid Type type,
                                 BindingResult bindingResult,
                                 @PathVariable(value = "id") long id,
                                 @RequestParam String typeName,
                                 Model model) {
    List<Type> res = typeRepository.findByTypeName(typeName);

    if (bindingResult.hasErrors()) {
      res = new ArrayList<>();
      res.add(type);
      model.addAttribute("typeEdit", res);
      return "/edit/type";
    }

    if (res.size() > 0) {
      ObjectError errorSlug = new ObjectError("typeName", "Type name is taken");
      bindingResult.addError(errorSlug);
      res = new ArrayList<>();
      res.add(type);
      model.addAttribute("typeEdit", res);
      return "/edit/type";
    } else {
      typeRepository.save(type);
      return "redirect:/type";
    }
  }
}
