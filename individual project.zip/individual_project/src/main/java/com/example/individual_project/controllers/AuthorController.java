package com.example.individual_project.controllers;

import com.example.individual_project.models.Author;
import com.example.individual_project.models.Country;
import com.example.individual_project.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class AuthorController {
  private final AuthorRepository authorRepository;

  @Autowired
  public AuthorController(AuthorRepository authorRepository) {
    this.authorRepository = authorRepository;
  }

  @GetMapping("/author")
  public String authorMain(Model model) {
    Iterable<Author> author = authorRepository.findAll();
    model.addAttribute("author", author);
    return "/view/author";
  }

  @GetMapping("/author/add")
  public String animeAdd(Author author) {
    return "/add/author";
  }

  @PostMapping("/author/add")
  public String cinemaAnimeAdd(@Valid Author author,
                               BindingResult bindingResult,
                               @RequestParam String name) {
    if (bindingResult.hasErrors()) {
      return "/add/author";
    }

    List<Author> res = authorRepository.findByName(name);

    if (res.size() > 0) {
      ObjectError error = new ObjectError("name", "Field is taken");
      bindingResult.addError(error);
      return "/add/author";
    } else {
      authorRepository.save(author);
      return "redirect:/author";
    }
  }

  @GetMapping("/author/search")
  public String authorSearch(Model model) {
    return "/search/author";
  }

  @PostMapping("/author/search/result")
  public String authorSearchResult(@RequestParam String name, Model model) {
    List<Author> result = authorRepository.findByName(name);
    model.addAttribute("result", result);

    List<Author> searchResult = authorRepository.findByNameContaining(name);
    model.addAttribute("searchResult", searchResult);
    return "/search/author";
  }

  @GetMapping("/author/{id}/delete")
  public String authorDelete(@PathVariable(value = "id") long id, Model model) {
    Author author = authorRepository.findById(id).orElseThrow();
    authorRepository.delete(author);
    return "redirect:/author";
  }

  @GetMapping("/author/{id}/edit")
  public String authorEdit(@PathVariable(value = "id") long id, Author author, Model model) {
    if (!authorRepository.existsById(id)) {
      return "redirect:/author";
    }
    Optional<Author> authors = authorRepository.findById(id);
    ArrayList<Author> res = new ArrayList<>();
    authors.ifPresent(res::add);
    model.addAttribute("authorEdit", res);
    return "/edit/author";
  }

  @PostMapping("/author/{id}/edit")
  public String cinemaCountryEdit(@Valid Author author,
                                BindingResult bindingResult,
                                @PathVariable(value = "id") long id,
                                @RequestParam String name,
                                Model model) {
    List<Author> res = authorRepository.findByName(name);

    if (bindingResult.hasErrors()) {
      res = new ArrayList<>();
      res.add(author);
      model.addAttribute("authorEdit", res);
      return "/edit/author";
    }

    if (res.size() > 0) {
      ObjectError errorTitle = new ObjectError("name", "Name is taken");
      ObjectError errorContent = new ObjectError("surname", "Surname is taken");
      bindingResult.addError(errorTitle);
      bindingResult.addError(errorContent);
      res = new ArrayList<>();
      res.add(author);
      model.addAttribute("authorEdit", res);
      return "/edit/author";
    } else {
      authorRepository.save(author);
      return "redirect:/author";
    }
  }
}
