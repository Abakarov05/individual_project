package com.example.individual_project.models;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import java.util.Collection;
import java.util.List;

@Entity
@Table(name = "entertainment")
public class Entertainment {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @NotEmpty(message = "The field can't be empty")
  private String title, content, episodes, chapters;
  @OneToMany(mappedBy = "entertainment", fetch = FetchType.LAZY)
  private Collection<Rating> rating;
  @ManyToOne(optional = false, cascade = CascadeType.DETACH)
  private Status status;
  @ManyToOne(optional = false, cascade = CascadeType.DETACH)
  private Country country;
  @ManyToOne(optional = false, cascade = CascadeType.DETACH)
  private Type type;
  @ManyToMany
  @JoinTable(name = "genre_entertainment", joinColumns = @JoinColumn(name = "entertainment_id"), inverseJoinColumns = @JoinColumn(name = "genre_id"))
  private List<Genre> genres;
  @ManyToMany
  @JoinTable(name = "author_entertainment", joinColumns = @JoinColumn(name = "entertainment_id"), inverseJoinColumns = @JoinColumn(name = "author_id"))
  private List<Author> authors;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public String getEpisodes() {
    return episodes;
  }

  public void setEpisodes(String episodes) {
    this.episodes = episodes;
  }

  public String getChapters() {
    return chapters;
  }

  public void setChapters(String chapters) {
    this.chapters = chapters;
  }

  public Status getStatus() {
    return status;
  }

  public void setStatus(Status status) {
    this.status = status;
  }

  public Country getCountry() {
    return country;
  }

  public void setCountry(Country country) {
    this.country = country;
  }

  public Type getType() {
    return type;
  }

  public void setType(Type type) {
    this.type = type;
  }

  public Collection<Rating> getRating() {
    return rating;
  }

  public void setRating(Collection<Rating> rating) {
    this.rating = rating;
  }

  public List<Genre> getGenres() {
    return genres;
  }

  public void setGenres(List<Genre> genres) {
    this.genres = genres;
  }

  public List<Author> getAuthors() {
    return authors;
  }

  public void setAuthors(List<Author> authors) {
    this.authors = authors;
  }

  public Entertainment(String title, String content, String episodes, String chapters, Type type, Country country, Status status) {
    this.title = title;
    this.content = content;
    this.episodes = episodes;
    this.chapters = chapters;
    this.type = type;
    this.country = country;
    this.status = status;
  }

  public Entertainment() {
  }
}
