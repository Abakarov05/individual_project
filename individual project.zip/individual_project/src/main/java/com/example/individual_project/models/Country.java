package com.example.individual_project.models;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import java.util.Collection;

@Entity
@Table(name = "country")
public class Country {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @NotEmpty(message = "The field can't be empty")
  private String name;
  @ManyToOne(optional = false, cascade = CascadeType.DETACH)
  private Slug slug;
  @OneToMany(mappedBy = "country", fetch = FetchType.LAZY)
  private Collection<Entertainment> entertainments;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Slug getSlug() {
    return slug;
  }

  public void setSlug(Slug slug) {
    this.slug = slug;
  }

  public Collection<Entertainment> getEntertainments() {
    return entertainments;
  }

  public void setEntertainments(Collection<Entertainment> entertainments) {
    this.entertainments = entertainments;
  }

  public Country(String name, Slug slug) {
    this.name = name;
    this.slug = slug;
  }

  public Country(){}
}
