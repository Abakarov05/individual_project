package com.example.individual_project.controllers;

import com.example.individual_project.models.Role;
import com.example.individual_project.models.User;
import com.example.individual_project.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import java.util.Collections;

@Controller
public class RegistrationController {
  private final UserRepository userRepository;
  private final PasswordEncoder passwordEncoder;

  @Autowired
  public RegistrationController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
    this.userRepository = userRepository;
    this.passwordEncoder = passwordEncoder;
  }

  @GetMapping("/signup")
  public String signup(){
    return "/auth/signup";
  }

  @PostMapping("/signup")
  public String addUser(User user, Model model){
    User userFromDB = userRepository.findByUsername(user.getUsername());

    if (userFromDB != null){
      model.addAttribute("message", "Username is taken");
      return "/auth/signup";
    }

    user.setActive(true);
    user.setRole(Collections.singleton(Role.User));
    user.setPassword(passwordEncoder.encode(user.getPassword()));
    userRepository.save(user);
    return "redirect:/";
  }
}
