package com.example.individual_project.repositories;

import com.example.individual_project.models.Slug;
import com.example.individual_project.models.Status;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface StatusRepository extends CrudRepository<Status, Long> {
  List<Status> findByStatusName(String statusName);
  List<Status> findByStatusNameContaining(String statusName);
  Status findStatusByStatusName(String statusName);
}
