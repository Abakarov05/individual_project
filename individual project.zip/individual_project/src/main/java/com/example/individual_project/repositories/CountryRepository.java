package com.example.individual_project.repositories;

import com.example.individual_project.models.Country;
import com.example.individual_project.models.Slug;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface CountryRepository extends CrudRepository<Country, Long> {
  List<Country> findByName(String name);
  List<Country> findByNameContaining(String name);
  Country findCountryByName(String name);
}
