package com.example.individual_project.models;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import java.util.Collection;

@Entity
public class Status {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @NotEmpty(message = "The field can't be empty")
  private String statusName;
  @OneToMany(mappedBy = "status", fetch = FetchType.LAZY)
  private Collection<Entertainment> entertainments;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getStatusName() {
    return statusName;
  }

  public void setStatusName(String statusName) {
    this.statusName = statusName;
  }

  public Collection<Entertainment> getEntertainments() {
    return entertainments;
  }

  public void setEntertainments(Collection<Entertainment> entertainments) {
    this.entertainments = entertainments;
  }

  public Status(String statusName, Collection<Entertainment> entertainments) {
    this.statusName = statusName;
    this.entertainments = entertainments;
  }

  public Status(){}
}
