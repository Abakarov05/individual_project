package com.example.individual_project.models;

public enum Role {
  User;
}
