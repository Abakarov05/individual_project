package com.example.individual_project.repositories;

import com.example.individual_project.models.Country;
import com.example.individual_project.models.Rating;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface RatingRepository extends CrudRepository<Rating, Long> {
  List<Rating> findByName(String name);
  List<Rating> findByNameContaining(String name);
  Rating findCountryByName(String name);
}
