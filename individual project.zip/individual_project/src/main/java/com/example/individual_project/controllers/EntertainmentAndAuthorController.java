package com.example.individual_project.controllers;

import com.example.individual_project.models.Author;
import com.example.individual_project.models.Country;
import com.example.individual_project.models.Entertainment;
import com.example.individual_project.repositories.AuthorRepository;
import com.example.individual_project.repositories.EntertainmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class EntertainmentAndAuthorController {

  private final EntertainmentRepository entertainmentRepository;
  private final AuthorRepository authorRepository;

  @Autowired
  public EntertainmentAndAuthorController(EntertainmentRepository entertainmentRepository, AuthorRepository authorRepository) {
    this.entertainmentRepository = entertainmentRepository;
    this.authorRepository = authorRepository;
  }

  @GetMapping("/entertainment_and_author")
  public String entertainmentAndAuthorMain(Model model) {
    Iterable<Entertainment> entertainments = entertainmentRepository.findAll();
    model.addAttribute("entertainments", entertainments);
    Iterable<Author> authors = authorRepository.findAll();
    model.addAttribute("authors", authors);
    return "/add/entertainmentAndAuthors";
  }

  @PostMapping("/person")
  public String personAdd(@RequestParam String entertainment, @RequestParam String author, Model model) {
    Entertainment entertainment1 = entertainmentRepository.findEntertainmentByTitle(entertainment);
    Author author1 = authorRepository.findAuthorByName(author);
    var entertainments = author1.getEntertainments();
    entertainments.add(entertainment1);
    author1.setEntertainments(entertainments);
    entertainmentRepository.save(entertainment1);
    return "/add/entertainmentAndAuthors";
  }
}
