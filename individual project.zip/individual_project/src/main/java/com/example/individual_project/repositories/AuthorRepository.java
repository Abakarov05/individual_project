package com.example.individual_project.repositories;

import com.example.individual_project.models.Author;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface AuthorRepository extends CrudRepository<Author, Long> {
  List<Author> findByName(String name);
  List<Author> findByNameContaining(String name);
  Author findAuthorByName(String name);
}
